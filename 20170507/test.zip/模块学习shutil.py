#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: Even

import shutil,os

# f1 = open("模块学习random.py")
# f2 = open("模块学习random_shutiltest.py","w")
# shutil.copyfileobj(f1,f2)

shutil.copy("/Users/chenxu/PycharmProjects/test/20170201/readme","copytest")

print(os.stat("/Users/chenxu/PycharmProjects/test/20170201/readme"))

shutil.make_archive("test",format="zip",root_dir="/Users/chenxu/PycharmProjects/test/20170507")